Walmart Sales Prediction


⇒	The main objective was to forecast weekly sales for each department in 45 Walmart stores located in different regions and also to carry out statistical testing and validation of the models

⇒	This project features a exploratory analysis and my predictive model was primarily based on linear regression

⇒	Predict which departments are affected with the holiday markdown events and the extent of impact.

⇒	We would also like to create a linear model to find a specific value for Weekly Sales that we want to predict. This line of best fit is intended to approximate further data points based on the line that we find in our training data.

⇒	Perform dimensionality reduction to improve prediction error by shrinkage in order to reduce overfitting.

